# Portfolio-Site
## Udacity Project 2:  Build a Portfolio Site

## Description
Build a Portfolio Site project is a part of the Udacity Full Stack Web Developer Nanodegree.This project creates a portfolio showing different skills and projects. Design mockup file was provided by Udacity.  

## Project contents

This project consists of the following files:

* index.html - It is the main file to generate the web page.
* css - This folder contains the style file which is used for styling the index.html file.
* images - This folder contains images to be used in index.html file.
* README.md- It describes documnetation of the project.

## How to run the project

  - Download the code
  - Extract compressed file
  - Open the file
  - Run the file, `index.html`
  - This will open up a page in your web browser
  - Hover over the different options to see details
 
## Bugs and feature requests

Have a bug or a feature request? contact me (See Contact info BELOW)

## Contact

* shreya28171@gmail.com